import streamlit as st
from sqlalchemy import text
from db import engine

# 🔐 Validar sesión
if not st.session_state.get("logged_in"):
    st.error("❌ Debes iniciar sesión")
    st.stop()

# 🔐 Validar rol admin
if st.session_state.get("rol") != "admin":
    st.error("⛔ Acceso solo para administradores")
    st.stop()

st.title("Panel de Administrador")

st.caption(f"Usuario: {st.session_state.get('usuario')} | Rol: {st.session_state.get('rol')}")

st.sidebar.title("Administración")

seccion = st.sidebar.radio(
    "Gestionar:",
    [
        "👨‍🏫 Profesores",
        "👤 Alumnos",
        "📅 Asistencias"
    ]
)
# ======================
# MENSAJES
# ======================
if st.session_state.get("alumno_actualizado"):
    st.success("✅ Alumno actualizado")
    del st.session_state["alumno_actualizado"]

if st.session_state.get("alumno_eliminado"):
    st.success("🗑️ Alumno desactivado")
    del st.session_state["alumno_eliminado"]

if st.session_state.get("asistencia_actualizada"):
    st.success("✅ Asistencia actualizada")
    del st.session_state["asistencia_actualizada"]

if st.session_state.get("asistencia_eliminada"):
    st.success("🗑️ Asistencia eliminada")
    del st.session_state["asistencia_eliminada"]

if seccion == "👨‍🏫 Profesores":
    st.subheader("Gestión de Profesores")
    st.info("Crear, editar o desactivar profesores")

    if st.session_state.get("profesor_creado"):
        st.success("✅ Profesor creado correctamente")
        del st.session_state["profesor_creado"]

    if st.session_state.get("profesor_actualizado"):
        st.success("💾 Cambios guardados correctamente")
        del st.session_state["profesor_actualizado"]

    if st.session_state.get("profesor_eliminado"):
        st.success("🗑️ Profesor eliminado correctamente")
        del st.session_state["profesor_eliminado"]

    query_profesores = text("""
    SELECT id_profesor, usuario, rol, activo
    FROM profesores
    ORDER BY usuario
    """)

    with engine.begin() as conn:
        profesores = conn.execute(query_profesores).fetchall()

    for p in profesores:
        col1, col2, col3, col4, col5 = st.columns([3, 2, 2, 2, 1])

        with col1:
            st.write(p.usuario)

        with col2:
            rol_nuevo = st.selectbox(
                "Rol",
                ["profesor", "admin"],
                index=0 if p.rol == "profesor" else 1,
                key=f"rol_{p.id_profesor}"
            )

        with col3:
            activo_nuevo = st.checkbox(
                "Activo",
                value=p.activo,
                key=f"activo_{p.id_profesor}"
            )

        with col4:
            if st.button("💾 Guardar", key=f"save_prof_{p.id_profesor}"):

                query_update = text("""
                UPDATE profesores
                SET rol = :rol, activo = :activo
                WHERE id_profesor = :id
                """)

                with engine.begin() as conn:
                    conn.execute(
                        query_update,
                        {
                            "rol": rol_nuevo,
                            "activo": activo_nuevo,
                            "id": p.id_profesor
                        }
                    )

                st.session_state["profesor_actualizado"] = True
                st.rerun()

        with col5:
            if st.button("🗑️", key=f"del_prof_{p.id_profesor}"):

                query_delete = text("""
                DELETE FROM profesores
                WHERE id_profesor = :id
                """)

                with engine.begin() as conn:
                    conn.execute(query_delete, {"id": p.id_profesor})

                st.session_state["profesor_eliminado"] = True
                st.rerun()

    st.subheader("Nuevo profesor")

    with st.form("form_nuevo_profesor", clear_on_submit=True):
        nuevo_usuario = st.text_input("Usuario")
        nueva_password = st.text_input("Contraseña", type="password")
        nuevo_rol = st.selectbox("Rol", ["profesor", "admin"])
        activo = st.checkbox("Activo", value=True)

        guardar = st.form_submit_button("Crear profesor")

        if guardar:
            if not nuevo_usuario or not nueva_password:
                st.warning("Completa usuario y contraseña")
            else:
                query_insert = text("""
                INSERT INTO profesores (usuario, password, rol, activo)
                VALUES (:usuario, :password, :rol, :activo)
                """)

                with engine.begin() as conn:
                    conn.execute(
                        query_insert,
                        {
                            "usuario": nuevo_usuario,
                            "password": nueva_password,
                            "rol": nuevo_rol,
                            "activo": activo
                        }
                    )

                st.session_state["profesor_creado"] = True
                st.rerun()

elif seccion == "👤 Alumnos":
    st.subheader("Gestión de Alumnos")
    st.info("Editar información de alumnos registrados")

    query = text("""
    SELECT id_alumno, nombre, accion, fecha_nacimiento, grupo, torneos
    FROM alumno
    ORDER BY nombre
    """)

    with engine.begin() as conn:
        alumnos = conn.execute(query).fetchall()

    busqueda = st.text_input("🔍 Buscar alumno")

    if busqueda:
        alumnos = [a for a in alumnos if busqueda.lower() in a.nombre.lower()]

    with st.container(height=500):
        for a in alumnos:
            col1, col2, col3, col4, col5, col6 = st.columns([3, 1, 2, 2, 2, 1])

            with col1:
                nombre = st.text_input("Nombre", a.nombre, key=f"nom_{a.id_alumno}")

            with col2:
                accion = st.text_input("Acción", a.accion, key=f"acc_{a.id_alumno}")

            with col3:
                fecha_nacimiento = st.date_input(
                    "Nacimiento",
                    a.fecha_nacimiento,
                    key=f"fec_{a.id_alumno}"
                )

            with col4:
                opciones_grupo = [
                    "Mini Tenis",
                    "Principiantes - Intermedio",
                    "Avanzados",
                    "Equipo de competencia"
                ]

                # índice seguro
                if a.grupo in opciones_grupo:
                    idx = opciones_grupo.index(a.grupo)
                else:
                    idx = 0   # o el que tú quieras por defecto

                grupo = st.selectbox(
                    "Grupo",
                    opciones_grupo,
                    index=idx,
                    key=f"grupo_{a.id_alumno}"
                )

            with col5:
                torneos = st.checkbox("Torneos", a.torneos, key=f"tor_{a.id_alumno}")

            with col6:
                if st.button("💾", key=f"save_al_{a.id_alumno}"):

                    query_update = text("""
                    UPDATE alumno
                    SET nombre = :nombre,
                        accion = :accion,
                        fecha_nacimiento = :fecha,
                        grupo = :grupo,
                        torneos = :torneos
                    WHERE id_alumno = :id
                    """)

                    with engine.begin() as conn:
                        conn.execute(
                            query_update,
                            {
                                "nombre": nombre,
                                "accion": accion,
                                "fecha": fecha_nacimiento,
                                "grupo": grupo,
                                "torneos": torneos,
                                "id": a.id_alumno
                            }
                        )

                    st.session_state["alumno_actualizado"] = True
                    st.rerun()

#=================
# ASISTENCIAS
#=================

elif seccion == "📅 Asistencias":
    st.subheader("📅 Gestión de Asistencias")
    st.info("Corregir o modificar asistencias")

    query = text("""
    SELECT a.id_asistencia,
           al.nombre,
           a.fecha,
           a.estado,
           a.hora_llegada,
           a.observaciones,
           a.fecha_registro
    FROM asistencias a
    JOIN alumno al ON al.id_alumno = a.id_alumno
    ORDER BY a.fecha DESC
    """)

    with engine.begin() as conn:
        asistencias = conn.execute(query).fetchall()

    with st.container(height=550):
        for r in asistencias:
            col1, col2, col3, col4, col5, col6, col7 = st.columns(
                [3, 2, 2, 2, 3, 2, 1]
            )

            with col1:
                st.write(r.nombre)

            with col2:
                fecha = st.date_input("Fecha", r.fecha, key=f"fec_{r.id_asistencia}")

            with col3:
                estados = ["Asistió", "Retardo", "Falta"]
                estado = st.selectbox(
                    "Estado",
                    estados,
                    index=estados.index(r.estado),
                    key=f"est_{r.id_asistencia}"
                )

            with col4:
                hora_llegada = None
                if estado == "Retardo":
                    hora_llegada = st.time_input(
                        "Hora llegada",
                        r.hora_llegada,
                        key=f"hora_{r.id_asistencia}"
                    )
                else:
                    st.write("—")

            with col5:
                observaciones = st.text_input(
                    "Observaciones",
                    r.observaciones or "",
                    key=f"obs_{r.id_asistencia}"
                )

            with col6:
                st.caption("Registrado")
                st.write(r.fecha_registro.strftime("%Y-%m-%d %H:%M"))

            with col7:
                if st.button("💾", key=f"save_as_{r.id_asistencia}"):

                    query_update = text("""
                    UPDATE asistencias
                    SET fecha = :fecha,
                        estado = :estado,
                        hora_llegada = :hora,
                        observaciones = :obs
                    WHERE id_asistencia = :id
                    """)

                    with engine.begin() as conn:
                        conn.execute(
                            query_update,
                            {
                                "fecha": fecha,
                                "estado": estado,
                                "hora": hora_llegada,
                                "obs": observaciones,
                                "id": r.id_asistencia
                            }
                        )

                    st.session_state["asistencia_actualizada"] = True
                    st.rerun()

                if st.button("🗑️", key=f"del_as_{r.id_asistencia}"):

                    query_delete = text("""
                    DELETE FROM asistencias
                    WHERE id_asistencia = :id
                    """)

                    with engine.begin() as conn:
                        conn.execute(query_delete, {"id": r.id_asistencia})

                    st.session_state["asistencia_eliminada"] = True
                    st.rerun()